package facade;

import entidades.ItensCompra;
import entidades.Produto;
import entidades.Compra;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CompraFacade extends AbstractFacade<Compra>{

    @PersistenceContext(unitName = "posjava2018jsfPU")
    private EntityManager em;
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CompraFacade() {
        super(Compra.class);
    }

    @Override
    public void salvar(Compra entity) {
        for(ItensCompra it : entity.getItensCompra()){
            Produto p = it.getProduto();
            p.setEstoque(p.getEstoque() + it.getQuantidade());
            em.merge(p);
        }
        super.salvar(entity);
    }

    @Override
    public List<Compra> listaTodos() {
        List<Compra> retorno = super.listaTodos();
        for(Compra v : retorno){
            v.getItensCompra().size();
            v.getContasPagar().size();
        }
        return retorno;
    }
    
    
    
}
