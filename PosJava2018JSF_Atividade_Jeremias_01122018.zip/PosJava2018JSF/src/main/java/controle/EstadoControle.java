package controle;

import com.ocpsoft.pretty.faces.annotation.URLAction;
import com.ocpsoft.pretty.faces.annotation.URLMapping;
import com.ocpsoft.pretty.faces.annotation.URLMappings;
import entidades.Estado;
import facade.EstadoFacade;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;


@SessionScoped
@ManagedBean
@URLMappings(mappings = {
    @URLMapping(id = "novoEstado", pattern = "/estado/novo", viewId = "/faces/estado/estadoedita.xhtml"),
    @URLMapping(id = "listaEstado", pattern = "/estado/listar", viewId = "/faces/estado/estadolista.xhtml"),
    @URLMapping(id = "editaEstado", pattern = "/estado/edita/#{estadoControle.id}", viewId = "/faces/estado/estadoedita.xhtml")
})
public class EstadoControle implements Serializable {

    private Estado estado;
    @EJB
    private EstadoFacade estadoFacade;
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    @URLAction(mappingId = "novoEstado", phaseId = URLAction.PhaseId.RENDER_RESPONSE, onPostback = false)
    public void novo(){
        estado = new Estado();
    }
    
    public void salvar(){
        estadoFacade.salvar(estado);
        estado = new Estado();
    }
    
    public void excluir(Estado est){
        try {
            estadoFacade.remover(est);
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(
                    null, new FacesMessage(
                            FacesMessage.SEVERITY_ERROR,
                            "O estado não pode ser removido, pois possui dependencias!",
                            null));
        }
        
    }
    
    @URLAction(mappingId = "editaEstado", phaseId = URLAction.PhaseId.RENDER_RESPONSE, onPostback = false)
    public void editarporid(){
        this.estado = estadoFacade.buscar(id);
    }
    
    public void editar(Estado est){
        this.estado = est;
    }

    public List<Estado> getListaEstados() {
        return estadoFacade.listaTodos();
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

}
