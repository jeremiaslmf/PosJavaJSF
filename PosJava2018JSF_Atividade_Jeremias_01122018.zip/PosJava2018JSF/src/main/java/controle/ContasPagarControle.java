package controle;

import entidades.BaixaContasPagar;
import entidades.ContasPagar;
import facade.ContasPagarFacade;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

//@RequestScoped
//@ViewScoped
@SessionScoped
//@ApplicationScoped
@ManagedBean
public class ContasPagarControle implements Serializable {

    private ContasPagar contasPagar;
    private BaixaContasPagar baixaContasPagar;
    @EJB
    private ContasPagarFacade contasPagarFacade;
    
    public void baixar(){
        baixaContasPagar.setContasPagar(contasPagar);
        contasPagar.getBaixas().add(baixaContasPagar);
        baixaContasPagar = new BaixaContasPagar();
    }

    public BaixaContasPagar getBaixaContasPagar() {
        return baixaContasPagar;
    }

    public void setBaixaContasPagar(BaixaContasPagar baixaContasPagar) {
        this.baixaContasPagar = baixaContasPagar;
    }

    public void novo() {
        contasPagar = new ContasPagar();
    }

    public void salvar() {
        contasPagarFacade.salvar(contasPagar);
        contasPagar = new ContasPagar();
    }

    public void excluir(ContasPagar est) {
        try {
            contasPagarFacade.remover(est);
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(
                    null, new FacesMessage(
                            FacesMessage.SEVERITY_ERROR,
                            "O contasPagar não pode ser removido, pois possui dependencias!",
                            null));
        }

    }

    public void editarBaixa(ContasPagar cp) {
        baixaContasPagar = new BaixaContasPagar();        
        this.contasPagar = cp;
    }

    public List<ContasPagar> getListaContasPagar() {
        return contasPagarFacade.listaTodos();
    }

    public ContasPagar getContasPagar() {
        return contasPagar;
    }

    public void setContasPagar(ContasPagar contasPagar) {
        this.contasPagar = contasPagar;
    }

}
