package controle;

import converter.ConverterGenerico;
import converter.MoneyConverter;
import entidades.ContasPagar;
import entidades.ItensCompra;
import entidades.Compra;
import entidades.Pessoa;
import entidades.Produto;
import facade.CompraFacade;
import facade.PessoaFacade;
import facade.ProdutoFacade;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@SessionScoped
@ManagedBean
public class CompraControle implements Serializable {

    private Compra compra;
    private ItensCompra itensCompra;
    @EJB
    private CompraFacade compraFacade;
    @EJB
    private PessoaFacade pessoaFacade;
    private ConverterGenerico pessoaConverter;
    @EJB
    private ProdutoFacade produtoFacade;
    private ConverterGenerico produtoConverter;
    private MoneyConverter moneyConverter;
    private Date primeiraParcela;
    private Integer numParcelas;

    public Date getPrimeiraParcela() {
        return primeiraParcela;
    }

    public void setPrimeiraParcela(Date primeiraParcela) {
        this.primeiraParcela = primeiraParcela;
    }

    public Integer getNumParcelas() {
        return numParcelas;
    }

    public void setNumParcelas(Integer numParcelas) {
        this.numParcelas = numParcelas;
    }

    public MoneyConverter getMoneyConverter() {
        if (moneyConverter == null) {
            moneyConverter = new MoneyConverter();
        }
        return moneyConverter;
    }

    public void setMoneyConverter(MoneyConverter moneyConverter) {
        this.moneyConverter = moneyConverter;
    }


    public void geraParcelas(){
        compra.setContasPagar(new ArrayList<ContasPagar>());
        Double valorParcela = compra.getValorTotal() / numParcelas;
        Date dtVen = primeiraParcela;
        for (int i = 1; i <= numParcelas; i++) {
            ContasPagar cr = new ContasPagar();
            cr.setDataLancamento(compra.getDataCompra());
            cr.setDataVencimento(dtVen);
            cr.setNumeroParcela(i);
            cr.setPessoa(compra.getPessoa());
            cr.setValor(valorParcela);
            cr.setCompra(compra);
            compra.getContasPagar().add(cr);
            
            Calendar cal = Calendar.getInstance();
            cal.setTime(dtVen);
            cal.add(Calendar.MONTH, 1);
            dtVen = cal.getTime();
        }
    }
    
    public void addItem() {
        Double estoque = itensCompra.getProduto().getEstoque();
        ItensCompra itemTemp = null;
        for (ItensCompra it : compra.getItensCompra()) {
            if (it.getProduto().equals(itensCompra.getProduto())) {
                itemTemp = it;
                estoque = estoque + it.getQuantidade();
            }
        }
        
        if (itemTemp == null) {
            itensCompra.setCompra(compra);
            compra.getItensCompra().add(itensCompra);
        } else {
            itemTemp.setQuantidade(itemTemp.getQuantidade() + itensCompra.getQuantidade());
            itemTemp.setPreco(itensCompra.getPreco());
        }
        itensCompra = new ItensCompra();

    }

    public void setaPrecoItem() {
        itensCompra.setPreco(itensCompra.getProduto().getPreco());
    }

    public List<Produto> listaProdutosFiltrando(String filtro) {
        return produtoFacade.listaFiltrando(filtro, "nome");
    }

    public ConverterGenerico getProdutoConverter() {
        if (produtoConverter == null) {
            produtoConverter = new ConverterGenerico(produtoFacade);
        }
        return produtoConverter;
    }

    public void setProdutoConverter(ConverterGenerico produtoConverter) {
        this.produtoConverter = produtoConverter;
    }

    public ItensCompra getItensCompra() {
        return itensCompra;
    }

    public void setItensCompra(ItensCompra itensCompra) {
        this.itensCompra = itensCompra;
    }

    public void novo() {
        compra = new Compra();
        itensCompra = new ItensCompra();
    }

    public ConverterGenerico getPessoaConverter() {
        if (pessoaConverter == null) {
            pessoaConverter = new ConverterGenerico(pessoaFacade);
        }
        return pessoaConverter;
    }

    public void setPessoaConverter(ConverterGenerico pessoaConverter) {
        this.pessoaConverter = pessoaConverter;
    }

    public List<Pessoa> listaPessoasFiltrando(String filtro) {
        return pessoaFacade.listaFiltrando(filtro, "nome");
    }

    public void salvar() {
        compraFacade.salvar(compra);
        compra = new Compra();
    }

    public void excluir(Compra cid) {
        compraFacade.remover(cid);
    }

    public void editar(Compra cid) {
        this.compra = cid;
    }

    public List<Compra> getListaCompras() {
        return compraFacade.listaTodos();
    }

    public Compra getCompra() {
        return compra;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

}
